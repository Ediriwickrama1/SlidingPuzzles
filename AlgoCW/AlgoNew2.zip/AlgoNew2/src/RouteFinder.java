/**
 * Name: Samadhi Ediriwickrama
 * Student ID: 20221862/ w1985625
 */

import java.util.*;

/**
 * RouteFinder class is responsible for finding a path from the start point to the end point
 * on the given IceField grid.
 */
public class RouteFinder {
    private IceField iceField; // The IceField grid to find the path on

    /**
     * Constructs a RouteFinder object with the specified IceField grid.
     * @param iceField The IceField grid to find the path on.
     */
    public RouteFinder(IceField iceField) {
        this.iceField = iceField;
    }

    /**
     * Computes the path from the start point to the end point on the IceField grid.
     * @return A list of strings representing the path from start to end.
     */
    public List<String> computePath() {
        Node startNode = iceField.getStartPoint();
        Node endNode = iceField.getEndPoint();
        Node[][] map = iceField.getMatrix();

        Queue<Node> frontier = new LinkedList<>();
        Map<Node, Node> pathMap = new HashMap<>();
        Map<Node, String> pathDescription = new HashMap<>();

        frontier.add(startNode);
        pathMap.put(startNode, null);

        int[] directionRow = {-1, 0, 1, 0, -1};
        String[] directionName = {"up", "right", "down", "left"};

        // Perform BFS traversal to find the path
        while (!frontier.isEmpty()) {
            Node currentNode = frontier.poll();
            if (currentNode == endNode) break;

            for (int i = 0; i < 4; i++) {
                Node nextNode = glide(currentNode, directionRow[i], directionRow[i + 1], map);
                if (nextNode != null && !pathMap.containsKey(nextNode)) {
                    pathMap.put(nextNode, currentNode);
                    pathDescription.put(nextNode, "Move " + directionName[i] + " to (" + nextNode.row + ", " + nextNode.col + ")");
                    frontier.add(nextNode);
                }
            }
        }

        // Trace back the path from end to start and construct path description
        return tracePath(pathMap, pathDescription, endNode);
    }

    /**
     * Glide function simulates movement from a start node in the specified direction
     * until a non-empty cell or boundary is reached.
     * @param start The starting node.
     * @param dRow The change in row direction.
     * @param dCol The change in column direction.
     * @param grid The grid representing the IceField.
     * @return The node reached after gliding in the specified direction.
     */
    private Node glide(Node start, int dRow, int dCol, Node[][] grid) {
        int row = start.row;
        int col = start.col;
        row += dRow;
        col += dCol;
        // Glide until a non-empty cell or boundary is reached
        while (isValid(row, col, grid) && grid[row][col].cellType == '.') {
            row += dRow;
            col += dCol;
        }
        if (isValid(row, col, grid) && grid[row][col].cellType != '0') {
            return grid[row][col];
        }
        // Return the previous node if the glide direction is blocked
        row -= dRow;
        col -= dCol;
        return grid[row][col];
    }

    /**
     * Checks if the specified row and column indices are within the grid boundaries.
     * @param row The row index.
     * @param col The column index.
     * @param grid The grid representing the IceField.
     * @return True if the indices are valid, false otherwise.
     */
    private boolean isValid(int row, int col, Node[][] grid) {
        return row >= 0 && col >= 0 && row < grid.length && col < grid[col].length;
    }

    /**
     * Traces back the path from the end node to the start node and constructs the path description.
     * @param pathMap The map containing the path from each node to its predecessor.
     * @param pathDescription The map containing the description of movements for each node.
     * @param finish The end node of the path.
     * @return A list of strings representing the path from start to end.
     */
    private List<String> tracePath(Map<Node, Node> pathMap, Map<Node, String> pathDescription, Node finish) {
        List<String> path = new ArrayList<>();
        Node step = finish;

        // Trace back the path and construct path description
        while (pathMap.get(step) != null) {
            String move = pathDescription.get(step);
            // Adjust node indices for human-readable format
            move = move.replace("(" + step.row + ", " + step.col + ")",
                    "(" + (step.row + 1) + ", " + (step.col + 1) + ")");
            path.add(move);
            step = pathMap.get(step);
        }
        // Add starting point to the path
        path.add("Start at (" + (step.row + 1) + "," + (step.col + 1) + ")");
        Collections.reverse(path); // Reverse the path to start from the beginning
        return path;
    }
}
