/**
 * Name: Samadhi Ediriwickrama
 * Student ID: 20221862 / w1985625
 */

import java.io.*;
import java.util.*;

/**
 * IceField class represents the grid-based terrain where the route finding algorithm will operate.
 */
public class IceField {
    private Node[][] matrix; // 2D array to store nodes representing each cell in the grid
    private Node startPoint; // Start point node
    private Node endPoint; // End point node

    /**
     * Constructs an IceField object and loads the map from the given file path.
     * @param path The file path to load the map from.
     * @throws IOException If an I/O error occurs while reading the map file.
     */
    public IceField(String path) throws IOException {
        loadMap(path);
    }

    /**
     * Loads the map from the given file path into the matrix.
     * @param path The file path to load the map from.
     * @throws IOException If an I/O error occurs while reading the map file.
     */
    private void loadMap(String path) throws IOException {
        List<String> lines = new ArrayList<>();

        // Read map file line by line
        try (BufferedReader buffer = new BufferedReader(new FileReader(path))) {
            String currentLine;
            while ((currentLine = buffer.readLine()) != null) {
                // Skip empty lines
                if (!currentLine.trim().isEmpty()) {
                    lines.add(currentLine);
                }
            }
        }

        // Throw exception if no map data is found
        if (lines.isEmpty()) {
            throw new IllegalArgumentException("The input file is empty or invalid.");
        }

        // Determine the number of rows and columns in the grid
        int rows = lines.size();
        int cols = lines.stream().mapToInt(String::length).max().orElseThrow(
                () -> new IllegalArgumentException("Error determining the map width.")
        );

        // Initialize the matrix with the determined size
        matrix = new Node[rows][cols];

        // Populate the matrix with nodes representing each cell
        for (int i = 0; i < rows; i++) {
            String line = lines.get(i);
            for (int j = 0; j < cols; j++) {
                char terrain = j < line.length() ? line.charAt(j) : '.';
                matrix[i][j] = new Node(i, j, terrain);
                // Set the start point and end point nodes if found in the map
                if (terrain == 'S') startPoint = matrix[i][j];
                if (terrain == 'F') endPoint = matrix[i][j];
            }
        }
    }

    /**
     * Retrieves the start point node.
     * @return The start point node.
     */
    public Node getStartPoint() {
        return startPoint;
    }

    /**
     * Retrieves the end point node.
     * @return The end point node.
     */
    public Node getEndPoint() {
        return endPoint;
    }

    /**
     * Retrieves the matrix representing the grid.
     * @return The 2D array of nodes representing the grid.
     */
    public Node[][] getMatrix() {
        return matrix;
    }
}
