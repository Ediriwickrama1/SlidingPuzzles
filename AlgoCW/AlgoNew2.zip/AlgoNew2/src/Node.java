/**
 * Name: Samadhi Ediriwickrama
 * Student ID: 20221862/ w1985625
 *
 * Node class represents a cell in the grid.
 */
public class Node {
    int row, col; // Row and column indices of the cell
    char cellType; // Type of terrain in the cell

    /**
     * Constructs a Node object with the specified row, column, and cell type.
     * @param row The row index of the cell.
     * @param col The column index of the cell.
     * @param cellType The type of terrain in the cell.
     */
    public Node(int row, int col, char cellType) {
        this.row = row;
        this.col = col;
        this.cellType = cellType;
    }
}


