/**
 * Name: Samadhi Ediriwickrama
 * Student ID: 20221862/ w1985625
 *
 * SlidingPuzzleSolver class contains the main method to solve the sliding puzzle problem.
 */
public class SlidingPuzzleSolver {

    /**
     * The main method of the SlidingPuzzleSolver class.
     * @param args The command line arguments.
     */
    public static void main(String[] args) {
        try {
            int i = 1; // Counter for step numbering
            IceField field = new IceField("map.txt"); // Create an IceField object by loading the map from the file "map.txt"
            RouteFinder finder = new RouteFinder(field); // Create a RouteFinder object with the IceField object
            // Compute the path using the RouteFinder object and iterate over each step in the path
            for (String step : finder.computePath()) {
                i++; // Increment step counter
                System.out.println(i +") "+step); // Print the step number and description
            }
        } catch (Exception e) {
            // Print error message if an exception occurs during execution
            System.out.println("Error: " + e.getMessage());
        }
    }

}
